import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {

        // creating frames
        JFrame frame = new JFrame();
        frame.setSize(400,400);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //frame.setVisible(true);

        //creating panels
        JPanel panel1 = new JPanel();
        panel1.setLayout(new GridLayout(2,2,10,10));
        JPanel panel2 = new JPanel();
        panel2.setSize(10,10);


        // Creating Labels
        JLabel namelabel = new JLabel("Name");
        JTextField namefield = new JTextField();

        JLabel rollnolabel = new JLabel("Roll No");

        JTextField rollnotextfield = new JTextField();

        JButton  Addbutton = new JButton();
        Addbutton.setMargin(new Insets(10,10,10,10));
        Addbutton.setText("Save Data");

        panel1.add(namelabel);
        panel1.add(namefield);
        panel1.add(rollnolabel);
        panel1.add(rollnotextfield);

        panel2.add(Addbutton);

        // creating main panel to add panel1 and panel 2
        JPanel mainpanel = new JPanel();
        mainpanel.add(panel1);
        mainpanel.add(panel2);
        mainpanel.setLayout(new BoxLayout(mainpanel,BoxLayout.Y_AXIS));
        frame.add(mainpanel);
        //frame.add(Box.createRigidArea(new Dimension(20, 20)));
        frame.setVisible(true);

        Addbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String name = namefield.getText();
                String Rollno = rollnotextfield.getText();


                String url = ("jdbc:mysql://localhost:3306/practice?user=root&password=12345678");

                try {
                    Connection con = DriverManager.getConnection(url);
                    String Querystring = ("insert into student3 (Name , Rollno) values (?, ?)");
                   // jdbc:mysql://localhost:3306/practice?user=root&password=12345678
                    PreparedStatement statement = con.prepareStatement(Querystring);
                    statement.setString(1,name);
                    statement.setString(2,Rollno);
                    statement.executeUpdate();

                    System.out.println("data is successfully inserted");



                } catch (SQLException ex) {
                    System.out.println("data is not inserted");
                } ;

            }
        });




        System.out.println("All good!");
    }

}